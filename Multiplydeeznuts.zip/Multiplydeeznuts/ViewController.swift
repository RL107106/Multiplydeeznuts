//
//  ViewController.swift
//  Multiplydeeznuts
//
//  Created by NATHAN GEHRKE on 10/10/18.
//  Copyright © 2018 Nathan Gehrke. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var ProductLabel: UILabel!
    @IBOutlet weak var numberOneTextfield: UITextField!
    @IBOutlet weak var numberTwoTextfield: UITextField!
      @IBOutlet weak var MarioKartImageView: UIImageView!
  
    
    var image = #imageLiteral(resourceName: "Buff.png")
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func onMultiplyButtonTapped(_ sender: Any) {
     let number1 = Int(numberOneTextfield.text!)
     let number2 = Int(numberTwoTextfield.text!)
      
        
        
 var result = number1! * number2!
        ProductLabel.text = String(result)
        //let x : Int = 42
        //var myString = String
        
    
        if result == 64 {
     
            MarioKartImageView.image = #imageLiteral(resourceName: "Buff")
        }
            
            
            
        
            
            
        }
        
        
        

    
    
    
   
       
     
        
        

        
    
    
    
 
    
    
    
    
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
   





}

}
